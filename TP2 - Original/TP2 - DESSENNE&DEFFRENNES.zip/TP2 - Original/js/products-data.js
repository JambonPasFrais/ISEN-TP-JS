let products_data = [
    { idProd:'0', name: 'Métier à Tisser', time: '30', components: ['14','15','16']},
    { idProd:'1', name: 'Bocal à Cookies', time: '15', components: ['0','1','2','3','4','5','6']},
    { idProd:'2', name: 'Beaume à lèvres', time: '15', components: ['7','8','9','10']},
    { idProd:'3', name: 'Post-it maison', time: '25', components: ['11','12','13']},
    { idProd:'4', name: 'Eponge Tawashi', time: '5', components: ['17','13']},
    { idProd:'5', name: 'Liqueur', time: '30', components: ['18','19','20','23','24','6']},
    { idProd:'6', name: 'Lessive', time: '14', components: ['6','20','21','22']},
];